---
name: Bug report
about: Create a report to help us improve, make sure to include a full debug log. 
title: "[BUG] "
labels: bug
assignees: zombiB

---

1-Describe the bug:

2-Debug log:
go to matrix settings
under tools click on loguploader
than click the upload button
and share the QR code or the URL 


3-Screenshots:if needed


