<br/>
<p align="center">
  <a href="https://github.com/zombiB/zombi-addons/tree/master">
    <img src="https://raw.githubusercontent.com/zombiB/zombi-addons/master/plugin.video.matrix/icon.png" alt="Logo" width="150" height="150">
  </a>

  <h3 align="center">Matrix Kodi Addon</h3>

  <p align="center">
 ماتريكس هي اضافة عربية تسمح لك بتصفح أشهر مواقع الفيديو العربية على تطبيق كودي

  <div class="container" align="center">
    <p align="center">
   للابلاغ عن مشاكل في الاضافة :

[![images](https://img.shields.io/badge/Github-Issues-blue.svg?style=for-the-badge)](https://github.com/zombiB/zombi-addons/issues)
<br />
</div>
